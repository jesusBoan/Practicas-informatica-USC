#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Importar aqui abb.h permite no repetir la definicion de 
// tipoelem. Si no lo hiciesemos tendriamos que copiarla
// en la implementacion. 
#include "abb.h"
#include "definiciones.h"

///////////////////////// ESTRUCTURAS DE DATOS
struct elementoLexico
{
    tipoclave lexema;
    tipoelem constante;
};

struct celda {
    el componente;
	struct celda *izq, *der;
};

//////////////////////// FUNCIONES

tipoclave lexemaElemento(el e){
    return e->lexema;
}

tipoelem constanteElemento(el e){
    return e->constante;
}

void setElementoLexico(el *e, tipoclave cl, tipoelem c){
    (*e)->lexema = (tipoclave)malloc((strlen(cl)+1)*sizeof(char));
    strcpy((*e)->lexema, cl);

    (*e)->constante = c;
}

void inicializarElementoLexico(el *e){
    *e = (el)malloc(sizeof(struct elementoLexico));
}

el crearElementoLexico(tipoclave cl, tipoelem c){
    el e = NULL;
    inicializarElementoLexico(&e);

    e->lexema = NULL;
    e->lexema = (tipoclave)malloc((strlen(cl)+1)*sizeof(char));
    strcpy(e->lexema, cl);

    e->constante = c;
    //printf("Creo el elemento: %s-%d\n", e->lexema, e->constante);
    return e;
}

/**
 * Función que compara 2 claves utilizando
 * strcmp(), devuelve 0 si son iguales, <0 si 
 * la segunda clave es mayor y >0 si la primera 
 * es mayor.
 * @param cl1 clave 1
 * @param cl2 clave 2
 */
int compararClaves(tipoclave cl1, tipoclave cl2){
	return strcmp(cl1, cl2); 
}

void crearArbol(abb *A) {
	*A = NULL;
}

void imprimirArbol(abb A){
    if(!es_vacio(A->izq))   imprimirArbol(A->izq);
    printf("|Lexema: %s\t\tConstante: %d|\n", A->componente->lexema, A->componente->constante);
    if(!es_vacio(A->der))   imprimirArbol(A->der);
}

void buscarElemento(abb *A, el * element, tipoclave clave){
    (*element)->lexema = NULL;
    (*element)->lexema = (tipoclave)malloc((strlen(clave)+1)*sizeof(char));

    if (!es_vacio(*A)) {
        int comp = compararClaves(clave, (*A)->componente->lexema);
    
        if (comp == 0) { 		// cl == A->lexema
            strcpy((*element)->lexema, clave);
            (*element)->constante = (*A)->componente->constante;
        } else if (comp < 0) { 	// cl < A->lexema
            buscarElemento(&((*A)->izq), element, clave);
        } else { 				// cl > A->lexema
            buscarElemento(&((*A)->der), element, clave);
        }    
    } else{
        strcpy((*element)->lexema, clave);
        (*element)->constante = ID;
        insertar(A, crearElementoLexico(clave, ID));
    }  
}

void insertar(abb *A, el elementoLexico) {
    if (es_vacio(*A)) {
        *A = (abb) malloc(sizeof (struct celda));
        (*A)->componente = elementoLexico;
        (*A)->izq = NULL;
        (*A)->der = NULL;
        //printf("Inserto el lexema %s y su constante %d\n", (*A)->componente->lexema, (*A)->componente->constante);
        return;
    } 
    int comp = compararClaves(elementoLexico->lexema, (*A)->componente->lexema);
    if (comp > 0 ) {
        insertar(&(*A)->der, elementoLexico);
    } else {
        insertar(&(*A)->izq, elementoLexico);
    }
}

unsigned es_vacio(abb A) {
	return A == NULL;
}

/**
 * Devuelve el subarbol izquierdo de A
 * @param A - Arbol original
 */
abb izq(abb A) {
    return A->izq;
}

/**
 * Devuelve el subarbol derecho de A
 * @param A - Arbol original
 */
abb der(abb A) {
    return A->der;
}

/**
 * Elimina un nodo del árbol
 * @param A nodo del árbol
 */
void destruirComponente(abb *A){
    free((*A)->componente->lexema);
    (*A)->componente->lexema = NULL;
    free((*A)->componente);
    (*A)->componente = NULL;
}

void destruirArbol(abb *A) {
	if (!es_vacio(*A)) {
		destruirArbol(&((*A)->izq));
		destruirArbol(&((*A)->der));
        destruirComponente(A);
		free(*A);
		*A = NULL;
	}
}

/**
 * Comprueba si el elemento con clave <cl> existe en el arbol <A>
 * @param A
 * @param cl
 */
unsigned es_miembro(abb A, tipoclave cl) {
    if (es_vacio(A)) {
        return 0;
    } 
    int comp = compararClaves(cl, A->componente->lexema);
    
    if (comp == 0) { 	//cl == A->constante
        return 1;
    } 
    if (comp > 0) {		//cl > A->constante
        return es_miembro(A->der, cl);
    } 
    //cl < A->constante
    return es_miembro(A->izq, cl);
}
