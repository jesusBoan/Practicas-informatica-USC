#!/bin/bash

flex --header-file=lex.yy.h flexPruebas.l

gcc -Wall -c -o gestorErrores.o gestorErrores.c
gcc -Wall -c -o abb.o abb.c
gcc -Wall -c -o ts.o ts.c
gcc -Wall -c -o lex.yy.o lex.yy.c
gcc -Wall -c -o sintactico.o sintactico.c
gcc -Wall -c -o main.o main.c

gcc -Wall main.o lex.yy.o sintactico.o ts.o abb.o gestorErrores.o -o final