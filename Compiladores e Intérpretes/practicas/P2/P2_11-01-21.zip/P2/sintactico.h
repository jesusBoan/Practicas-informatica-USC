#include "lex.yy.h"
#include "abb.h"

/**
 * Mientras no llegue un END OF FILE llamará al 
 * analizador léxico pidiendo lexemas. Luego imprimirá los mismos.
 * @param A puntero al árbol binario que representa la Tabla de Símbolos
*/
void start(abb *A); //función con el bucle principal del programa, llamará a siguienteElemento() del analizador léxico