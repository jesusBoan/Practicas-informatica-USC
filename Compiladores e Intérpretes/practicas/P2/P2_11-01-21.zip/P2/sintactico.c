#include "sintactico.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * Función que imprime el contenido de un elemento léxico
 * @param e elemento léxico
*/
void imprimirElemento(el e){
    printf("<%d,'%s'>\n", constanteElemento(e), lexemaElemento(e));
}

void start(abb *A){
    int eof = 0; //end of file
    el e = NULL;
    while (!eof)
    {
        inicializarElementoLexico(&e);
        eof = siguienteElemento(A, &e);
        imprimirElemento(e);
        e = NULL;
    }
    
}
