#include "gestorErrores.h"
#include <stdio.h>

void printError(char * mensaje, int numeroLinea){
    if(numeroLinea != 0){
        printf("(Linea: %d) ", numeroLinea);
    }
    printf("Error: %s\n", mensaje);
}