#ifndef __ABB_LIB

#define __ABB_LIB

typedef struct elementoLexico *el;

/**
 * Tipo de dato abstracto para arbol binario con clave de 
 * ordenacion y elemento de celda.
 */

typedef char *tipoclave;
typedef int tipoelem;

//TIPO OPACO, no sabemos como esta construido celda 
// https://es.wikipedia.org/wiki/Puntero_opaco
typedef struct celda *abb;

// Si no tuviesemos importado abb.h en abb.c podriamos 
// lograr mas opacidad usando esta definicion para el arbol:
// typedef void *abb;
// Y teniendo en el abb.c la definicion typedef struct celda *abb;
// Tenemos que decidir que preferimos mayor opacidad o menos
// codigo repetido, en este caso hemos optado por lo segundo. 
// 

/////////////////////////////// FUNCIONES
/**
 * Devuelve la clave del elemento 'e'. 
 * @param e Elemento léxico.
 */
tipoclave lexemaElemento(el e);
/**
 * Devuelve la cosntante del elemento 'e'. 
 * @param e Elemento léxico.
 */
tipoelem constanteElemento(el e);

/**
 * Asigna clave y constante el elemento léxico 'e'. 
 * @param e Puntero a la estructura del elementoLexico
 * @param cl clave
 * @param c constante
 */
void setElementoLexico(el *e, tipoclave cl, tipoelem c);

/**
 * Reserva memoria para la estructura del elemento. 
 * @param e Puntero a la estructura del elementoLexico
 */
void inicializarElementoLexico(el *e);

/**
 * devuelve un elemento léxico con la clave y
 * la constante que pasamos por parámetros
 * @param cl clave
 * @param c constante
 * */
el crearElementoLexico(tipoclave cl, tipoelem c);

/**
 * Crea el arbol vacio. 
 * @param A Puntero al arbol. Debe estar inicializado.
 */
void crearArbol(abb *A);

/**
 * Imprime el árbol desde el nodo más a la izquierda
 * hasta el último a la derecha
 * @param A Árbol binario
*/
void imprimirArbol(abb A);

/**
 * Busca y devuelve la información del elemento del árbol
 * A cuya clave coincida con 'clave'. Si no existe, lo inserta
 * con 'clave' como lexema e 'ID' como constante.
 * @param A Arbol binario
 * @param element elemento léxico donde guardamos la información del nodo
 * @param clave clave mediante la cual buscamos el elemento
 */
void buscarElemento(abb *A, el * element, tipoclave clave);

/**
 * Inserta un nuevo nodo en el arbol para el elemento elementoLexico
 * del que toma su clave y constante. Esta clave no debe existir en
 * el arbol.
 * @param A Arbol binario
 * @param elementoLexico Informacion del nuevo nodo. 
 */
void insertar(abb *A, el elementoLexico);

/**
 * Comprueba si el arbol esta vacio
 * @param A El arbol binario
 */
unsigned es_vacio(abb A);

/**
 * Destruye el arbol recursivamente
 * @param A El arbol que queremos destruir
 */
void destruirArbol(abb *A);


#endif	/* __ABB_LIB */
