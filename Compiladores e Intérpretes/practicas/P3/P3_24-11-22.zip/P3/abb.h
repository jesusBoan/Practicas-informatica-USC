#ifndef ABB_H
#define ABB_H

#include <stdbool.h>
#include "ts.h"
/**
 * Tipo de dato abstracto para arbol binario con clave de 
 * ordenacion y elemento de celda.
 */

typedef char *tipoclave;
typedef simboloTS tipoelem;

//TIPO OPACO, no sabemos como esta construido celda 
// https://es.wikipedia.org/wiki/Puntero_opaco
typedef struct celda *abb;

// Si no tuviesemos importado abb.h en abb.c podriamos 
// lograr mas opacidad usando esta definicion para el arbol:
// typedef void *abb;
// Y teniendo en el abb.c la definicion typedef struct celda *abb;
// Tenemos que decidir que preferimos mayor opacidad o menos
// codigo repetido, en este caso hemos optado por lo segundo. 
// 

/////////////////////////////// FUNCIONES
void crea(abb *A);

void destruirArbol(abb *A);

bool esVacio(abb A);

tipoelem * inserta(abb *A, tipoelem E);

tipoelem suprime_min(abb *A);

void suprime(abb *A, tipoelem E);

bool esMiembro(abb A, tipoelem E);

abb izq(abb A);

abb der(abb A);

void componente(abb A, tipoelem *E);

tipoelem * buscaNodo(abb A, tipoclave cl);

void modifica(abb *A, tipoclave cl, tipoelem nodo);

#endif