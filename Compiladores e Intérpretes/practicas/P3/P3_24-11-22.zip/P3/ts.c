#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "abb.h"
#include "consolaMatematica.tab.h"

abb TS;

// Funciones por defecto
struct initFunctionStruct functions[] = {
    {"sin", sin},
    {"cos", cos},
    {"tan", tan},
    {"asin", asin},
    {"acos", acos},
    {"atan", atan},
    {"sinh", sinh},
    {"cosh", cosh},
    {"tanh", tanh},
    {"log", log},
    {"log10", log10},
    {"ceil", ceil},
    {"floor", floor},
    {"exp", exp},
    {"sqrt", sqrt},
    {0,      0},
};

// Constantes por defecto
struct initConstantStruct constants[] = {
    {"pi", 3.14159265359},
    {"e",  2.71828182846},
    {0,    0},
};

void inicializar(){
    crea(&TS);
}

simboloTS * insertar(char *lexema, int tipo){
    tipoelem simboloTabla;
    simboloTabla.lexema = (char*)malloc((strlen(lexema)+1)*sizeof(char));
    strcpy(simboloTabla.lexema, lexema);
    simboloTabla.dataType = tipo;
    simboloTabla.data.variable = 0.0;
    return inserta(&TS, simboloTabla);
}

simboloTS * busca(char *cadena){
    simboloTS* simbolo = NULL;
    simbolo = buscaNodo(TS, cadena);
    return simbolo;
}

void imprimirNodo(abb arbol, int datatype){
    if(!esVacio(izq(arbol))){
        imprimirNodo(izq(arbol), datatype);
    }
    simboloTS s;
    componente(arbol, &s);
    if(s.dataType == datatype || datatype == 0){
        if (s.dataType != FNCT)
        {
            printf("| \033[0;32m%s\t\t\033[0;36m%f\t\033[0;37m%d |\n", s.lexema, s.data.variable, s.dataType);
        }else{
            printf("| \033[0;32m%s\t\t\t\t\033[0;37m%d |\n", s.lexema, s.dataType);
        }
    }
    if(!esVacio(der(arbol))){
        imprimirNodo(der(arbol), datatype);
    }
}

void imprimirTabla(int datatype){
    if(!esVacio(TS)){
        imprimirNodo(TS, datatype);
    }
    printf("-------------------------------------\n");
}


void destruirTabla(){
    destruirArbol(&TS);
}

void loadFunctions(struct initFunctionStruct *functions) {
    int i;
    for (i = 0; functions[i].name != 0; i ++) {
        simboloTS *input = insertar(functions[i].name, FNCT);
        input->data.functptr = functions[i].fnct;
        input->inicializado = true;
    }
}

void loadConstants(struct initConstantStruct *constants) {
    int i;
    for (i = 0; constants[i].name != 0; i ++) {
        simboloTS *input = insertar(constants[i].name, CONS);
        input->data.variable = constants[i].constantValue;
        input->inicializado = true;
    }
}