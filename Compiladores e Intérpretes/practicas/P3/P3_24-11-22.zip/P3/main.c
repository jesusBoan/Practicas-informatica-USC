#include "lex.yy.h"
#include "ts.h"
#include "consolaMatematica.tab.h"
#include <stdio.h>

int loadFile(char* filepath);

int main(int argc, char *argv[]) {
    inicializar();
    loadConstants(constants);
    loadFunctions(functions);
 // En caso de que se pase el nombre de un archivo como argumento, lo analizamos primero
    if (argc == 2) {
        loadFile(argv[1]);
    }

    // Asignamos la entrada y salida por defecto de flex
    yyin = stdin;
    yyout = stdout;
   

    printf("\n-----------------------------------------------------------\n");
    printf("---------------  Consola matemática - V1.0  ---------------\n");
    printf("-----------------------------------------------------------\n");
    printf("----------------------  AYUDA --> :?  ---------------------\n");
    printf("-----------------------------------------------------------\n");

    yyparse();
    return EXIT_SUCCESS;
}