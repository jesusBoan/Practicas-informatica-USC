#ifndef TS_H
#define TS_H

#include <stdio.h>
#include <stdbool.h>

struct elementTS
{
    char *lexema;
    bool inicializado;
    int dataType; //o VAR, CONST o FUNCT
    union
    {
        double variable;
        double (*functptr)();
    } data;
};

typedef struct elementTS simboloTS;

// Tipo de dato para las funciones por defecto
struct initFunctionStruct{
  char *name;       
  double (*fnct) (double);//function pointer
};

// Tipo de dato para las constantes por defecto
struct initConstantStruct{
    char *name;
    double constantValue;
};

extern struct initFunctionStruct functions[];
extern struct initConstantStruct constants[];

/*Función que crea el árbol e inserta en él las palabras reservadas junto a sus valores
de definiciones.h*/
void inicializar();

simboloTS * insertar(char *lexema, int tipo);

/*Función de impresión de los elementos almacenados en la tabla*/
void imprimirTabla(int datatype);

/*Función que libera la memoria reservada para la tabla*/
void destruirTabla();

simboloTS * busca(char *cadena); //esta la llama el analizador léxico para que busque un elemento, si no está, lo inserta. La función devuelve la constante identificadora del elemento

/* Funcion que carga las funciones por defecto en la tabla
 * de símbolos*/
void loadFunctions (struct initFunctionStruct* functions);

/* Funcion que carga las constantes por defecto en la tabla
 * de simbolos*/
void loadConstants (struct initConstantStruct* constants);

#endif