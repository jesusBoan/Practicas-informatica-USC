bison -d consolaMatematica.y
flex --header-file=lex.yy.h consolaMatematica.l
make