#!/bin/bash

[[ $(docker ps -f "name=compiladores" --format '{{.Names}}') == compiladores ]] ||
docker stop compiladores && docker rm compiladores

[[ $(docker images --format '{{.Repository}}' | grep compiladores_image) == compiladores_image ]] ||
docker image rm compiladores_image

echo "Creando imagen..."
docker build . -t compiladores_image

echo "Creando un contenedor en base a la imagen creada..."
contenedor=$(docker run -t --name compiladores compiladores_image) &

sleep 5

docker exec compiladores /bin/sh -c "./ejecutable"

docker stop compiladores
