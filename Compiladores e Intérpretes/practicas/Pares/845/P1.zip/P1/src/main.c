#include <stdio.h>
#include <stdlib.h>


#include "analizador_sintactico.h"


int main() {
	printf("main: Inicio del programa\n");

	// inicialización de las memorias estáticas de las clases
	inicializarSE ();
	printf("main: SE inicializados\n\n");

	inicializarTS ();
	printf("main: TS inicializados\n\n");

	inicializarPila ();
	printf("main: Pila inicializada\n\n");

	inicializarAL ();
	printf("main: AL inicializados\n\n");

	// impresión de la tabla hash con sólo palabras reservadas
	imprimirTabla();


	// análisis sintáctico
	printf("<><><><><><><><><><><><><><><><>\n");
	analisisSintactico();
	printf("<><><><><><><><><><><><><><><><>\n");

	// impresión de la tabla hash con todo
	imprimirTabla();


	// borrado de las memorias estáticas de las clases
	borrarAL ();
	printf("main: borrado AL\n");

	borrarPila ();
	printf("main: borrado Pila\n");

	borrarTS ();
	printf("main: borrado TS\n");

	borrarSE ();
	printf("main: borrado SE\n");

	return 0;
}
