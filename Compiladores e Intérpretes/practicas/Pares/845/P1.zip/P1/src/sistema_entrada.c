#include "sistema_entrada.h"
#include <unistd.h>


#define source "wilcoxon.py"


// estructura con la memoria del sistema de entrada
struct struct_SE {
	FILE * f;			// Puntero necesario para abrir el archivo
	char bloqueA[MAXBUFLEN];	// Bloques A y B. Tienen tamaño cte, por eso
	char bloqueB[MAXBUFLEN];	//   están definidos como char []
	int etapa;			// Indicador si bloqueA o bloqueB
	int caracter;			// Indicador de posición en el bloque
};


// variable donde se guarda la memoria del sistema de entrada
struct struct_SE SE;


// borrado del sistema de entrada
void borrarSE () {
	fclose(SE.f);
}


// lectura de un bloque
void leerBloque () {
	SE.etapa = (SE.etapa + 1) % 2;
	SE.caracter = 0;

	int leido;
	if (SE.etapa == 0)
		leido = fread(SE.bloqueA, sizeof(char), MAXBUFLEN - 1, SE.f);
	else
		leido = fread(SE.bloqueB, sizeof(char), MAXBUFLEN - 1, SE.f);

	if (ferror(SE.f) != 0) {
		fputs("Error leyendo el archivo\n", stderr);
		exit(-1);
	}

	if (leido < MAXBUFLEN - 1) {
		if (SE.etapa == 0)
			SE.bloqueA[leido - 1] = EOF;
		else
			SE.bloqueB[leido - 1] = EOF;
	}
}


// lectura de un caracter
char leerCaracter () {
	char caract;
	if (SE.etapa == 0)	// según la etapa, el caracter es de bloqueA o bloqueB
		caract = SE.bloqueA[SE.caracter];
	else
		caract = SE.bloqueB[SE.caracter];

	if (caract == EOF) {	// el caracter es EOF:
		if (SE.caracter >= MAXBUFLEN - 1) {	// es fin de bloque ?
			leerBloque();			// no -> cambiar bloque
			return leerCaracter();		// devolver el caracter
		} else {
			return EOF;			// si -> devolver EOF
		}
	} else {		// devolver caracter si este no es EOF
		SE.caracter++;
		return caract;
	}
}


// lectura de un caracter n elementos atrás
char anteriorCaracter (int elementosAtras) {
	// comprobación que no se pase más del anterior bloque
	if (elementosAtras > SE.caracter + MAXBUFLEN - 1) {
		return (char) 0;
	}

	char resultado;
	if (SE.caracter - elementosAtras < 0) { // este bloque o el anterior?
		if (SE.etapa == 0)
			resultado = SE.bloqueB[MAXBUFLEN - 2 + SE.caracter - elementosAtras];
		else
			resultado = SE.bloqueA[MAXBUFLEN - 2 + SE.caracter - elementosAtras];
	} else {	// en este bloque
		if (SE.etapa == 0)
			resultado = SE.bloqueA[SE.caracter - elementosAtras];
		else
			resultado = SE.bloqueB[SE.caracter - elementosAtras];
	}

	return resultado;
}


// inicialización del sistema de entrada
void inicializarSE () {
	SE.etapa = 1;	// etapa se pone a 1, porque luego leerBloque() lo cambiará a 0
	SE.caracter = 0;	// el primer caracter del bloque
	SE.bloqueA[MAXBUFLEN - 1] = EOF; // pongo EOF al final de los dos bloques
	SE.bloqueB[MAXBUFLEN - 1] = EOF;

	if ((SE.f = fopen(source, "rt")) == NULL) {	// abro el archivo
		printf("Error abriendo el archivo\n");
		exit(-1);
	}
	// leo el primer bloque, para tenerlo cargado cuando se llame a leerCaracter()
	leerBloque();
}
