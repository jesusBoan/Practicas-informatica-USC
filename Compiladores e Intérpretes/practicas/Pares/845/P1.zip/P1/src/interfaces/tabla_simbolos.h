#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "definiciones.h"

#define TAM 200		// tamaño inicial de la tabla
#define VACIO '\0'	// valor para las celdas vacías
#define BORRADO '?'	// valor para las celdas borradas


// estructura de cada celda
struct dato {
	char* lexema;	// clave
	int codigo;	// valor
};


// reserva de memoria e inicialización de la tabla (iserción de palabras reservadas)
void inicializarTS ();

// búsqueda (e inserción si no está) de una cadena alfanumérica
int buscar (char * lexema);

// borrado de la tabla hash y liberación de la memoria
void borrarTS ();

// impresión de la tabla hash
void imprimirTabla ();
