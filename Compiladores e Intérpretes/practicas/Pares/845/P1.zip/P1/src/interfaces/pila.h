#include <stdio.h>
#include <stdlib.h>


// función para meter elementos en la pila
void insertarPila (int num);

// función para quitar un elemento de la pila. Devuelve dicho elemento sacado
int quitarPila ();

// función para ver qué está en el tope de la pila
int mirarPila ();

// función para inicializar la pila
void inicializarPila ();


// función para borrar la pila
void borrarPila ();
