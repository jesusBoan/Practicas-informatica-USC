#include <stdlib.h>
#include <stdio.h>
#include <string.h>


// tamaño de los bufferes de lectura
#define MAXBUFLEN 200


// inicialización del sistema de entrada
void inicializarSE ();

// borrado del sistema de entrada
void borrarSE ();

// lectura del siguiente caracter de entrada
char leerCaracter();

// lectura de un caracter n elementos atrás
char anteriorCaracter (int elementosAtras);
