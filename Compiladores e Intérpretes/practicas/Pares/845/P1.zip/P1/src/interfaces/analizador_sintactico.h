#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "analizador_lexico.h"


// función para imprimir un componente léxico desde el analizador
void imprimirComponenteLexico (struct componente_lexico c);

// función para solicitar todos los componentes léxicos al analizador léxico
int analisisSintactico ();
