#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define COLOR_ROJO "\x1b[31m"
#define COLOR_RESET "\x1b[0m"


void imprimirError (char * buffer, char * error);
