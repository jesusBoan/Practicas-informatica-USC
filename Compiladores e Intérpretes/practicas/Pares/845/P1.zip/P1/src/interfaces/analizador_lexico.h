#include <string.h>
#include <stdlib.h>
#include <stdio.h>


#include "sistema_entrada.h"
#include "tabla_simbolos.h"
#include "pila.h"
#include "gestor_errores.h"
#include "definiciones.h"


#define TAMLEXINI	100	// tam inicial del buffer para los lexemas

#define E_START0	299	// inicio del archivo
#define E_START1	300	// inicio de línea
#define E_START2	301	// inicio de palabra (sin caracter ya leído)
#define E_START3	302	// inicio de palabra (con caracter ya leído)

#define E_EOF		309	// fin del archivo, quedan los DEDENTs
#define E_END		310	// fin del archivo, ya no queda nada por hacer

#define E_DEDENT_CALC	352	// devolviendo tantos DEDENTs como sea necesario

#define E_ID_KW		401	// identificador o palabra clave (keyword)
#define E_NUM		402	// número
#define E_NUM_ESP	403	// número especial


// componente léxico que se le devolverá al analizador sintáctico
struct componente_lexico {
	int codigo;
	char * lexema;
};


// función para inicializar y reservar la memoria del analizador léxico
void inicializarAL ();

// función para liberar la memoria y borrar el analizador léxico
void borrarAL ();

// función para obtener los componentes léxicos
struct componente_lexico analisisLexico ();

// función para borrar la memoria reservada por un componente léxico
// (analizador_sintactico llama a esta función cuando ya no va a usar
// el componente léxico obtenido)
void borrarComponenteLexico (struct componente_lexico c);
