#define UNKNOWN			0
#define START_CODE		1

#define ERROR			269

#define ID			280

#define NL			301
#define INDENT			302
#define DEDENT			303

#define STRING_LITERAL		401
#define DECINTEGER		404
#define BININTEGER 		405
#define HEXINTEGER		406
#define OCTINTEGER		407
#define FLOAT_NUMBER		410

#define END			420
