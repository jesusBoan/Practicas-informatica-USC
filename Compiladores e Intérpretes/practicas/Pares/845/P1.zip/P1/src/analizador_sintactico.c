#include "analizador_sintactico.h"

#include <unistd.h>

#define COLOR_RESET "\x1b[0m"
#define COLOR_AMARILLO "\x1b[33m"
#define COLOR_VERDE "\x1b[92m"


// impresión de los componentes léxicos y sus códigos, con colores
void imprimirComponenteLexico (struct componente_lexico c) {
	printf("<"COLOR_AMARILLO"%d"COLOR_RESET", \"", c.codigo);
	printf(COLOR_VERDE"%s"COLOR_RESET, c.lexema);
	printf("\">\n");
}


// peticiones de los componentes léxicos al analizador léxico, hasta que
// devuelva END (que implica que ya no hay más)
int analisisSintactico () {
	// se solicita y se obitene
	struct componente_lexico c = analisisLexico ();
	// se comprueba que no sea el fin del análisis
	while (c.codigo != END) {
		// se imprime el obtenido
		imprimirComponenteLexico (c);
		// después de imprimirlo se borra
		borrarComponenteLexico (c);
		// se obtiene el siguiente
		c = analisisLexico ();
	}
	// se borra el último
	borrarComponenteLexico (c);

	return 0;
}
