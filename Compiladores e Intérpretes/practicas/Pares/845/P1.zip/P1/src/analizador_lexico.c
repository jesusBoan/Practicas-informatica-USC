#include "analizador_lexico.h"


// declaración de estos métodos, para poder ser llamados desde métodos implementados más arriba
void automataInicio ();
void automataCom1 (char caracterClave);


// memoria del analizador léxico
struct struct_AL {
	int estado;	// estado en el que se encuentra el analizador léxico
	char caracterActual;	// último caracter leído
	char indentador;	// caracter que determina la indentación, ' ' o '\t'
	char * lexemaBuffer;	// buffer donde se va guardando el lexema
	size_t tamLexemaBuffer;	// tamaño del buffer del lexema
	// y, por último, el componente que se le pasa al analizador sintáctico
	struct componente_lexico componente;
};


// variable estática global con la memoria del analizador léxico
struct struct_AL AL;


// función para borrar la memoria del buffer
void borrarAL () { free (AL.lexemaBuffer); };


// función para asignar valores inicialiales y reservar memoria para el analizador léxico
void inicializarAL () {
	AL.estado = E_START0;
	AL.caracterActual = '\0';
	AL.indentador = '$';

	AL.tamLexemaBuffer = (size_t) TAMLEXINI;
	AL.lexemaBuffer = (char *) malloc (sizeof (char) * AL.tamLexemaBuffer);
	memset (AL.lexemaBuffer, '\0', sizeof(char) * AL.tamLexemaBuffer);

	AL.componente.codigo = START_CODE;
	AL.componente.lexema = NULL;
}


// función para borrar la memoria reservada por el analizador léxico
void borrarComponenteLexico (struct componente_lexico c) { free(c.lexema); }



// función para obtener el lexema del buffer e insertarlo en el componente léxico
// a pasar al analizador sintáctico. El estado depende de si se ha leído un caracter
// de más o no, por tanto ultimoCaracter influye en el estado.
void prepararLexema (int ultimoCaracter) {
	int tamLexema = strlen (AL.lexemaBuffer);
	int tamFinal;
	if (ultimoCaracter) {
		tamFinal = tamLexema;
		AL.estado = E_START3;
	} else {
		tamFinal = tamLexema;
		AL.estado = E_START2;
	}
	// por último, se copia el contenido del buffer al componente que se pasará
	// y se "vacía" el buffer llenándolo de '\0'
	AL.componente.lexema = (char *) malloc (sizeof (char) * (tamFinal + 1));
	memcpy (AL.componente.lexema, AL.lexemaBuffer, tamFinal);
	AL.componente.lexema[tamFinal] = '\0';
	memset (AL.lexemaBuffer, '\0', sizeof(char) * AL.tamLexemaBuffer);
}


// preparación de un lexema personalizado en el componente a pasar al analizador
// sintáctico
void prepararLexemaCustom (char * custom) {
	AL.componente.lexema = (char *) malloc (sizeof (char) * strlen (custom));
	strcpy (AL.componente.lexema, custom);
	memset (AL.lexemaBuffer, '\0', sizeof(char) * AL.tamLexemaBuffer);
}


// inclusión del caracterActual en el lexemaBuffer (buffer del lexema)
void aumentarLexema () {
	int tamLexema = strlen (AL.lexemaBuffer);
	if (tamLexema < (int) AL.tamLexemaBuffer - 1) AL.lexemaBuffer[tamLexema] = AL.caracterActual;
	else { // en caso de que el buffer sea muy pequeño, se reserva más memoria
		AL.tamLexemaBuffer *= 1.5;
		char * tmp = malloc (sizeof (char) * AL.tamLexemaBuffer);
		memset (AL.lexemaBuffer, '\0', sizeof(char) * AL.tamLexemaBuffer);
		memcpy (tmp, AL.lexemaBuffer, tamLexema);
		free (AL.lexemaBuffer);
		AL.lexemaBuffer = tmp;
	}
}


// función al acabar de leer el archivo, devolver tantos DEDENTs como hagan falta
// (dependiendo del número de elementos restantes en la pila)
void funcionFinal () {
	if (mirarPila () != 0) {
		AL.estado = E_EOF;
		quitarPila ();
		AL.componente.codigo = DEDENT;
		prepararLexemaCustom ("DEDENT");
	} else {
		AL.estado = E_END;
		AL.componente.codigo = END;
		prepararLexemaCustom ("EOF");
	}
}


// función para obtener cuántos caracteres de indentación hay en la línea,
// devuelve dicho número
int indentacion () {
	while (AL.caracterActual == '\n') AL.caracterActual = leerCaracter ();
	if (AL.caracterActual != ' ' && AL.caracterActual != '\t') return 0;
	int contador = 0;
	if (AL.indentador == '$') AL.indentador = AL.caracterActual;
	while (AL.caracterActual == ' ' || AL.caracterActual == '\t') {
		if (AL.caracterActual != AL.indentador) {
			AL.componente.codigo = ERROR;
			prepararLexemaCustom ("TabError");
			imprimirError ("TabError", "Error, tabulador incorrecto.");
			AL.estado = E_START3;
			contador = -1;
			break;
		} else {
			AL.caracterActual = leerCaracter ();
			contador++;
		}
	}
	return contador;
}


// automata para devolver el código de nueva línea
void automataNuevaLinea () {
	AL.componente.codigo = NL;
	prepararLexemaCustom ("NL");
	AL.estado = E_START1;
}


// autómata para ignorar comentarios
void automataComentario () {
	int seguir = 1;
	while (seguir) {
		AL.caracterActual = leerCaracter ();
		switch (AL.caracterActual) {
			case '\n':
				seguir = 0;
				automataNuevaLinea ();
				break;
			case EOF:
				seguir = 0;
				break;
		}
	}

	memset (AL.lexemaBuffer, '\0', sizeof(char) * AL.tamLexemaBuffer);
	AL.caracterActual = leerCaracter ();
	automataInicio();
}


// autómata para identificadores y palabras reservadas
void automataIdentificadores () {
	int seguir = 1;
	while (seguir) {
		AL.caracterActual = leerCaracter ();
		switch (AL.caracterActual) {
			case 'a' ... 'z':
			case 'A' ... 'Z':
			case '0' ... '9':
			case '_':
				aumentarLexema ();
				break;
			default:
				seguir = 0;
				break;
		}
	}
	prepararLexema (0);
	// el código de la cadena alfanumérica se busca en la TS
	AL.componente.codigo = buscar (AL.componente.lexema);
}



// autómata para Strings multilíneas (tres comas o comillas)
// tienen que aparecer esas 3 comas o comillas para indicar el fin
// del string
void automataTripleCom (char caracterClave) {
	int contador = 0;
	while (contador < 3) {
		AL.caracterActual = leerCaracter ();
		if (AL.caracterActual == caracterClave) {
			contador++;
		} else {
			if (AL.caracterActual == EOF) {
				AL.componente.codigo = ERROR;
				prepararLexemaCustom (AL.lexemaBuffer);
				AL.estado = E_START3;
				imprimirError (AL.lexemaBuffer, "Error, EOF en String"
						" multilínea");
				return;
			} else {
				contador = 0;
			}
		}
		aumentarLexema ();
	}
	AL.componente.codigo = STRING_LITERAL;
	prepararLexema (1);
}


// autómata para los strings encapsulados en comas o comillas,
// después de haber leído el caracter '\', que permite saltar 1 línea
void automataCom2 (char caracterClave) {
	AL.caracterActual = leerCaracter ();
	if (AL.caracterActual == caracterClave) {
		aumentarLexema ();
		aumentarLexema ();
	} else {
		if (AL.caracterActual == '\n') {
			AL.estado = E_START1;
			return;
		} else {
			aumentarLexema ();
			aumentarLexema ();
		}
	}
	automataCom1 (caracterClave);
}


// autómata para los strings encapsulados en comas o comillas
void automataCom1 (char caracterClave) {
	int seguir = 1;
	while (seguir) {
		AL.caracterActual = leerCaracter ();
		if (AL.caracterActual == caracterClave) {
			aumentarLexema ();
			seguir = 0;
		} else {
			switch (AL.caracterActual) {
				case '\\':
					automataCom2 (caracterClave);
					break;
				case '\n':
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, salto de"
						" línea en un string de comillas simples");
					return;
				default:
					break;
			}
			aumentarLexema ();
		}
	}
	AL.componente.codigo = STRING_LITERAL;
	prepararLexema (1);
}


// autómata para los hexinteger
void automataHexinteger () {
	aumentarLexema();
	int seguir = 1;
	int barrasBajas = 0;
	while (seguir) {
		AL.caracterActual = leerCaracter ();
		switch (AL.caracterActual) {
			case '0' ... '9':
			case 'a' ... 'f':
			case 'A' ... 'F':
				barrasBajas = 0;
				aumentarLexema ();
				break;
			case '_':
				if (barrasBajas != 0) {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, dos barras"
						" bajas seguidas en un hexinteger");
					return;
				}
				barrasBajas++;
				break;
			default:
				if (barrasBajas != 0) {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, hexinteger"
						" termina en una barra baja");
					return;
				}
				seguir = 0;
				break;
		}
	}
	AL.componente.codigo = HEXINTEGER;
	prepararLexema (0);
}


// autómata para los binintegers
void automataBininteger () {
	aumentarLexema();
	int seguir = 1;
	int barrasBajas = 0;
	while (seguir) {
		AL.caracterActual = leerCaracter ();
		switch (AL.caracterActual) {
			case '0' ... '1':
				barrasBajas = 0;
				aumentarLexema ();
				break;
			case '_':
				if (barrasBajas != 0) {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, dos barras"
						" bajas seguidas en un bininteger");
					return;
				}
				barrasBajas++;
				break;
			default:
				if (barrasBajas != 0) {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, bininteger"
						" termina en una barra baja");
					return;
				}
				seguir = 0;
				break;
		}
	}
	AL.componente.codigo = BININTEGER;
	prepararLexema (0);
}


// autómata para los octinteger
void automataOctinteger () {
	aumentarLexema();
	int seguir = 1;
	int barrasBajas = 0;
	while (seguir) {
		AL.caracterActual = leerCaracter ();
		switch (AL.caracterActual) {
			case '0' ... '7':
				barrasBajas = 0;
				aumentarLexema ();
				break;
			case '_':
				if (barrasBajas != 0) {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, dos barras"
						" bajas seguidas en un octinteger");
					return;
				}
				barrasBajas++;
				break;
			default:
				if (barrasBajas != 0) {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, octinteger"
						" termina en una barra baja");
					return;
				}
				seguir = 0;
				break;
		}
	}
	AL.componente.codigo = OCTINTEGER;
	prepararLexema (0);
}


// autómata para los exponentes de los floats
void automataExponentes () {
	AL.caracterActual = leerCaracter ();
	if (AL.caracterActual == '+' || AL.caracterActual == '-') {
		aumentarLexema ();
		AL.caracterActual = leerCaracter ();
	}
	if (AL.caracterActual < '0' || AL.caracterActual > '9') {
		AL.componente.codigo = ERROR;
		aumentarLexema ();
		prepararLexemaCustom (AL.lexemaBuffer);
		AL.estado = E_START3;
		imprimirError (AL.lexemaBuffer, "Error, exponente"
			" sin número");
		return;
	}
	int barrasBajas = 0;
	while (1) {
		switch (AL.caracterActual) {
			case '0' ... '9':
				barrasBajas = 0;
				aumentarLexema ();
				break;
			case '_':
				if (barrasBajas != 0) {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, dos barras"
						" bajas seguidas en un exponente");
					return;
				}
				barrasBajas++;
				break;
			default:
				if (barrasBajas != 0) {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, exponente"
						" termina en una barra baja");
					return;
				}
				AL.componente.codigo = FLOAT_NUMBER;
				prepararLexema (0);
				AL.estado = E_START2;
				return;
		}
		AL.caracterActual = leerCaracter ();
	}
}


// autómata para los floats
void automataFloats () {
	AL.caracterActual = leerCaracter ();
	if (AL.caracterActual >= '0' && AL.caracterActual <= '9') {
		aumentarLexema ();
		int seguir = 1;
		int barrasBajas = 0;
		while (seguir) {
			AL.caracterActual = leerCaracter();
			switch (AL.caracterActual) {
				case '0' ... '9':
					barrasBajas = 0;
					aumentarLexema ();
					break;
				case '_':
					if (barrasBajas != 0) {
						AL.componente.codigo = ERROR;
						aumentarLexema ();
						prepararLexemaCustom (AL.lexemaBuffer);
						AL.estado = E_START3;
						imprimirError (AL.lexemaBuffer, "Error, dos barras"
							" bajas seguidas en un float");
						return;
					}
					barrasBajas++;
					break;
				default:
					if (barrasBajas != 0) {
						AL.componente.codigo = ERROR;
						aumentarLexema ();
						prepararLexemaCustom (AL.lexemaBuffer);
						AL.estado = E_START3;
						imprimirError (AL.lexemaBuffer, "Error, float"
							" termina en una barra baja");
						return;
					}
					seguir = 0;
					break;
			}
		}
	}
	if (AL.caracterActual == 'e' || AL.caracterActual == 'E') {
		aumentarLexema ();
		automataExponentes ();
	} else {
		AL.componente.codigo = FLOAT_NUMBER;
		prepararLexema (0);
	}
}


// autómatas para los números especiales (bininteger, hexinteger, float....)
// todos estos números derivan de los números que empiezan por '0'
void automataNumEsp () {
	AL.caracterActual = leerCaracter ();
	switch (AL.caracterActual) {
		case 'b':
		case 'B':
			automataBininteger ();
			break;
		case 'o':
		case 'O':
			automataOctinteger ();
			break;
		case 'x':
		case 'X':
			automataHexinteger ();
			break;
		case '.':
			aumentarLexema ();
			automataFloats ();
			break;
		default:
			AL.componente.codigo = DECINTEGER;
			prepararLexema (0);
			break;
	}
}


// autómata para los números
void automataNum1 () {
	int seguir = 1;
	int barrasBajas = 0;

	while (seguir) {
		AL.caracterActual = leerCaracter ();
		switch (AL.caracterActual) {
			case '_':
				if (barrasBajas == 0) barrasBajas = 1;
				else {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, dos barras"
						" bajas seguidas en un número");
					return;
				}
				break;
			case '0' ... '9':
				barrasBajas = 0;
				aumentarLexema ();
				break;
			case '.':
				if (barrasBajas > 0) {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, hay una"
						" barra baja antes del punto");
					return;
				}
				aumentarLexema ();
				automataFloats ();
				return;
			case 'e':
			case 'E':
				aumentarLexema ();
				automataExponentes ();
				return;
			default:
				if (barrasBajas != 0) {
					AL.componente.codigo = ERROR;
					aumentarLexema ();
					prepararLexemaCustom (AL.lexemaBuffer);
					AL.estado = E_START3;
					imprimirError (AL.lexemaBuffer, "Error, número"
						" termina en una barra baja");
					return;
				}
				seguir = 0;
				break;
		}
	}
	AL.componente.codigo = DECINTEGER;
	prepararLexema (0);
}


// autómata para el punto (separar "math.sqrt" de "0.0")
void automataPunto () {
	AL.caracterActual = leerCaracter ();
	if (AL.caracterActual >= '0' && AL.caracterActual <= '9') {
		aumentarLexema ();
		automataFloats ();
	} else {
		AL.componente.codigo = (int) '.';
		prepararLexemaCustom (".");
		AL.estado = E_START2;
	}
}


// autómata para el inicio de un lexema
void automataInicio () {
	char caracterClave;
	char tokenBuffer[4];
	switch (AL.caracterActual) {
		case '#':
			// si es un comentario, sólo podrá devolver NL si el comentario
			// no es lo único que contiene la línea. Es por ello que este caso
			// del switch luego cae en el caso de nueva línea
			while (AL.caracterActual != '\n') {
				AL.caracterActual = leerCaracter ();
				if (AL.caracterActual == EOF) {
					funcionFinal ();
					return;
				}
			}
			__attribute__ ((fallthrough));
		case '\n':
			// sólo devolverá un único NL, siguiendo la especificación de Python
			while (AL.caracterActual == '\n') AL.caracterActual = leerCaracter ();
			if (AL.caracterActual == EOF) {
				funcionFinal ();
				return;
			}
			// si el anterior código fue NL, o fue INDENT o START_CODE, no puede
			// devolver un token NL, así que debe de analizar la identación de la
			// siguiente línea (por si puede devolver un token INDENT), y en caso
			// de no encontrar una indentación nueva, debe llamar de forma recursiva
			// a la función automataInicio para devolver el siguiente lexema.
			if (AL.componente.codigo == NL || AL.componente.codigo == INDENT ||
					AL.componente.codigo == START_CODE) {
				AL.estado = E_START2;
				int conteoIndent = indentacion ();
				if (conteoIndent < 0) return;
				if (conteoIndent > mirarPila()) {
					AL.componente.codigo = INDENT;
					prepararLexemaCustom ("INDENT");
					insertarPila (conteoIndent);
				} else {
					automataInicio ();
				}
			} else {
				automataNuevaLinea ();
			}
			break;
		case ' ':
			// los espacios no forman parte de un lexema, así que se asigna al
			// estado E_START2 (es decir, aún no se ha leído el 1er caracter
			// del lexema)
			AL.estado = E_START2;
			break;
		case 'a' ... 'z':
		case 'A' ... 'Z':
		case '_':
			// identificadores y palabras clave
			aumentarLexema ();
			automataIdentificadores ();
			break;
		case '0':
			// números y números especiales, ambos empiezan por 0
			aumentarLexema ();
			automataNumEsp ();
			break;
		case '1' ... '9':
			// números enteros y floats
			aumentarLexema ();
			automataNum1();
			break;
		case '\'':
		case '"':
			// strings y strings multilíneas. Para diferenciarlos,
			// es necesario leer los siguientes caracteres y ver si
			// coinciden tres caracteres iguales seguidos.
			caracterClave = AL.caracterActual;
			aumentarLexema ();
			AL.caracterActual = leerCaracter ();
			if (AL.caracterActual == caracterClave) {
				aumentarLexema ();
				AL.caracterActual = leerCaracter ();
				if (AL.caracterActual == caracterClave) {
					aumentarLexema ();
					automataTripleCom (caracterClave);
				} else {
					AL.componente.codigo = STRING_LITERAL;
					prepararLexema (0);
				}
			} else {
				aumentarLexema ();
				automataCom1 (caracterClave);
			}
			break;
		case '$':
		case '?':
		case '`':
			// caracteres no válidos
			AL.componente.codigo = ERROR;
			sprintf (tokenBuffer, "%c%c", AL.caracterActual, '\0');
			prepararLexemaCustom (tokenBuffer);
			AL.estado = E_START3;

			imprimirError (tokenBuffer, "Error, símbolo no válido");
			break;
		case '/':
		case '*':
		case '<':
		case '>':
			// caracteres pertenecientes a los casos: (de ejemplo '/')
			// /, /=, //, //=
			caracterClave = AL.caracterActual;
			AL.caracterActual = leerCaracter ();
			if (AL.caracterActual == '=' || AL.caracterActual == caracterClave) {
				if (AL.caracterActual == '=') {
					AL.componente.codigo = 1600 + (int) caracterClave;
					sprintf (tokenBuffer, "%c=", caracterClave);
					prepararLexemaCustom (tokenBuffer);
					AL.estado = E_START3;
				} else {
					AL.caracterActual = leerCaracter ();
					if (AL.caracterActual == '=') {
						AL.componente.codigo = 1800 + (int) caracterClave;
						sprintf (tokenBuffer, "%c%c=", caracterClave, caracterClave);
						prepararLexemaCustom (tokenBuffer);
						AL.estado = E_START3;
					} else {
						AL.componente.codigo = 2000 + (int) caracterClave;
						sprintf (tokenBuffer, "%c%c", caracterClave, caracterClave);
						prepararLexemaCustom (tokenBuffer);
						AL.estado = E_START2;
					}
				}
			} else {
				AL.componente.codigo = (int) caracterClave;
				sprintf (tokenBuffer, "%c%c", caracterClave, '\0');
				prepararLexemaCustom (tokenBuffer);
				AL.estado = E_START2;
			}
		break;
		case '@':
		case '=':
		case '+':
		case '-':
		case '%':
		case '!':
		case ':':
		case '&':
		case '|':
		case '^':
			// caracteres pertenecientes a los casos: (de ejemplo, +)
			// +, +=
			caracterClave = AL.caracterActual;
			AL.caracterActual = leerCaracter ();
			if (AL.caracterActual == '=') {
				AL.componente.codigo = 1600 + caracterClave;
				sprintf (tokenBuffer, "%c=", caracterClave);
				prepararLexemaCustom (tokenBuffer);
				AL.estado = E_START3;
			} else {
				AL.componente.codigo = (int) caracterClave;
				sprintf (tokenBuffer, "%c%c", caracterClave, '\0');
				prepararLexemaCustom (tokenBuffer);
				AL.estado = E_START2;
			}
			break;
		case '~':
		case '(':
		case ')':
		case '[':
		case ']':
		case '{':
		case '}':
		case ',':
		case ';':
			// caracteres que simbolizan un único lexema de por sí
			AL.componente.codigo = (int) AL.caracterActual;
			sprintf (tokenBuffer, "%c%c", AL.caracterActual, '\0');
			prepararLexemaCustom (tokenBuffer);
			AL.estado = E_START3;
			break;
		case '.':
			// caso especial del punto
			aumentarLexema ();
			automataPunto ();
			break;
		case EOF:
			// caso especial del EOF
			funcionFinal ();
			break;
		default:
			// caracter no reconocido
			AL.componente.codigo = ERROR;
			sprintf (tokenBuffer, "%c%c", AL.caracterActual, '\0');
			prepararLexemaCustom (tokenBuffer);
			imprimirError (tokenBuffer, "Error, caracter no reconocido.");
			AL.estado = E_START3;
			break;
	}
}


// función para obtener el componente léxico y devolverlo
struct componente_lexico analisisLexico () {
	int tamLexema;
	switch (AL.estado) {
		case E_END:
			// si el programa ya ha acabado, pero se vuelve a llamar al
			// método analisisLexico(), debe saltar un error, y cerrarse
			// el programa, ya que de otro modo puede entrar en bucle.
			// Este error se da debido a errores en la programación de
			// este programa y al uso de los métodos del analizador léxico.
			AL.componente.codigo = ERROR;
			prepararLexemaCustom ("END");
			imprimirError ("END", "Error, archivo ya leído.");
			exit(1);
			break;
		case E_EOF:
			// el archivo ya ha finalizado, queda por saber si quedan
			// tokens DEDENT por devolver o no
			funcionFinal ();
			return AL.componente;
		case E_START0:
			// inicio del archivo, es necesario leer algún caracter
			AL.caracterActual = leerCaracter ();
			__attribute__ ((fallthrough));
		case E_START1:
			// inicio de una nueva línea. Hay que ignorar líneas vacías
			while (AL.caracterActual == '\n') AL.caracterActual = leerCaracter ();
			// análisis si hay que devolver tokens INDENT o DEDENT
			int conteoIndent = indentacion ();
			if (conteoIndent < 0) return AL.componente; // tabError
			int topePila = mirarPila ();
			if (topePila != conteoIndent) {
				if (topePila < conteoIndent) {
					AL.estado = E_START2;
					AL.componente.codigo = INDENT;
					prepararLexemaCustom ("INDENT");
					insertarPila (conteoIndent);
				} else {
					// en caso de tener token DEDENT, pueden ser + de 1
					// por tanto, se usa el buffer para saber cuántos
					// y el estado para indicar que faltan tokens
					// DEDENT por devolver
					AL.estado = E_DEDENT_CALC;
					prepararLexemaCustom ("DEDENT");
					int dedentCount = 0;
					while (topePila > conteoIndent) {
						quitarPila ();
						topePila = mirarPila ();
						dedentCount++;
					}
					memset (AL.lexemaBuffer, (char) 17,
							sizeof (char) * (dedentCount - 1));
				}
				return AL.componente;
			}
			AL.estado = E_START2;
			break;
		case E_DEDENT_CALC:
			// si está en estado E_DEDENT_CALC, quedan tokens DEDENT por devolver
			tamLexema = strlen (AL.lexemaBuffer);
			if (tamLexema > 0) {
				AL.lexemaBuffer[tamLexema] = '\0';
				prepararLexemaCustom ("DEDENT");
				memset (AL.lexemaBuffer, (char) 17, sizeof (char) * (tamLexema - 1));
				return AL.componente;
			}
			break;
		case E_START3:
			// nuevo lexema, pero aún no se ha leído el primer caracter
			AL.caracterActual = leerCaracter();
			__attribute__ ((fallthrough));
		case E_START2:
			// nuevo lexema, ya se ha leído el primer caracter
			// Es necesario saltarse los espacios para no analizarlos. Los espacios
			// no forman parte de la indentación, porque no estamos en el estado E_START1
			while (AL.caracterActual == ' ') AL.caracterActual = leerCaracter ();
			break;
		default:
			// estado no reconocido. Se devuelve error y se coloca el estado a fin del
			// análisis.
			AL.componente.codigo = ERROR;
			sprintf (AL.lexemaBuffer, "%c%c", AL.caracterActual, '\0');
			prepararLexemaCustom (AL.lexemaBuffer);
			imprimirError (AL.lexemaBuffer, "Error, analizador léxico en un"
					" estado no reconocido.");
			AL.estado = E_END;
			break;
	}

	// se llama al método que prepara el lexema a devolver junto a su código, una vez se han
	// filtrado las indentaciones y estados especiales (además de leer el primer caracter del
	// lexema a analizar)
	automataInicio ();

	// se devuelve el componente formado
	return AL.componente;
}
