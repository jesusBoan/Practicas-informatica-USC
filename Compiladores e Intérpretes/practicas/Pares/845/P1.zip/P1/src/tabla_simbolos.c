#include "tabla_simbolos.h"


// memoria de la tabla de símbolos
struct struct_TS {
	char vacio;	// ubicación del valor vacío (no se puede usar la macro)
	char borrado;	// ubicación del valor borrado (no se puede usar la macro)
	int tamano;	// tamaño actual de la tabla
	int ocupado;	// elementos totales en la tabla
	struct dato * memoria;	// puntero a las celdas de la tabla hash
};


// variable estática del tipo struct_TS
struct struct_TS TS;


// función para borrar la tabla y liberar la memoria
void borrarTS () {
	for (int i = 0; i < TS.tamano; i++) {
		if (TS.memoria[i].lexema[0] != VACIO && TS.memoria[i].lexema[0] != BORRADO)
			free (TS.memoria[i].lexema);
	}
	free (TS.memoria);
}


// función para obtener la celda a partir de la clave
int hashear (char* clave) {
	int suma = 0;
	for (int i = 0; i < (int) strlen (clave); i++)
		suma = (suma * 256 + clave[i]) % TS.tamano;
	return suma;
}


// función para obtener la celda a partir de la clave,
// con recolocación cuadrática
int localizar (char* clave) {
	int aux;
	int indiceInicial = hashear (clave);

	for (int i = 0; i < TS.tamano; i++) {
		aux = (indiceInicial + i * i) % TS.tamano;
		if (TS.memoria[aux].lexema[0] == VACIO || TS.memoria[aux].lexema[0] == BORRADO) break;
		if (strcmp (TS.memoria[aux].lexema, clave) == 0) break;
	}
	TS.ocupado += 1;
	return aux;
}


// función para insertar un elemento en la tabla hash,
// sin tener en cuenta si está vacía
void insertar (char* clave, int hash, int codigo) {
	TS.memoria[hash].codigo = codigo;
	TS.memoria[hash].lexema = (char*) malloc (sizeof (clave));
	strcpy (TS.memoria[hash].lexema, clave);
}


// función para insertar un elemento en la tabla hash,
// insertándolo en una celda vacía, con el código de un
// identificador
void insercion_segura (char* clave) {
	int hash = localizar (clave);
	insertar (clave, hash, ID);
}


// igual que insercion_segura, pero se especifica el código
// que tendrá la celda. Se usa sólo para la inserción de
// palabras reservadas en la tabla, durante la inicialización
void insercion_segura_especifica (char* clave, int codigo) {
	int hash = localizar (clave);
	insertar(clave, hash, codigo);
}


// inserción de las palabras reservadas en la tabla
void identificadoresIniciales () {
	int n_elementos = 35;

	char * lista[n_elementos];
	lista[0] = "False";
	lista[1] = "None";
	lista[2] = "True";
	lista[3] = "and";
	lista[4] = "as";
	lista[5] = "assert";
	lista[6] = "async";
	lista[7] = "await";
	lista[8] = "break";
	lista[9] = "class";
	lista[10] = "continue";
	lista[11] = "def";
	lista[12] = "del";
	lista[13] = "elif";
	lista[14] = "else";
	lista[15] = "except";
	lista[16] = "finally";
	lista[17] = "for";
	lista[18] = "from";
	lista[19] = "global";
	lista[20] = "if";
	lista[21] = "import";
	lista[22] = "in";
	lista[23] = "is";
	lista[24] = "lambda";
	lista[25] = "nonlocal";
	lista[26] = "not";
	lista[27] = "or";
	lista[28] = "pass";
	lista[29] = "raise";
	lista[30] = "return";
	lista[31] = "try";
	lista[32] = "while";
	lista[33] = "with";
	lista[34] = "yield";

	int codigo[] = {
			500, 501, 502, 503, 504, 505,
			506, 507, 508, 509, 510, 511,
			512, 513, 514, 515, 516, 516,
			517, 518, 519, 520, 521, 522,
			523, 524, 525, 526, 527, 528,
			529, 530, 531, 532, 533, 534
			};

	for (int i = 0; i < n_elementos; i++)
		insercion_segura_especifica (lista[i], codigo[i]);
}


// reserva de memoria y asignación de valores iniciales
void inicializarTS () {
	TS.vacio = VACIO;
	TS.borrado = BORRADO;

	TS.tamano = TAM;
	TS.ocupado = 0;
	TS.memoria = (struct dato*) malloc(sizeof (struct dato) * TAM);

	for (int i = 0; i < TS.tamano; i++)
		TS.memoria[i].lexema = &(TS.vacio);

	identificadoresIniciales ();
}


// Agrandamiento de la tabla. Se reserva otro espacio de memoria mayor,
// se va mirando celda por celda en la vieja e insertando en la nueva.
// por último se borra la memoria de la vieja
void reestructurarTabla () {
	int tamInicial = TS.tamano;
	struct dato * tmp = TS.memoria;
	TS.tamano = (int)(TS.tamano * 1.5);
	TS.memoria = (struct dato *) malloc (sizeof (struct dato) * TS.tamano);
	TS.ocupado = 0;

	for (int i = 0; i < TS.tamano; i++) TS.memoria[i].lexema = &(TS.vacio);
	for (int i = 0; i < tamInicial; i++) {
		if (tmp[i].lexema[0] != VACIO && tmp[i].lexema[0] != BORRADO) {
			insercion_segura_especifica (tmp[i].lexema, tmp[i].codigo);
			free (tmp[i].lexema);
		}
	}
	free (tmp);
}


// función para obtener el código a partir de un lexema. Si no se encuentra en la tabla,
// se inserta con el código de un identificador. Si la tabla ya está bastante llena,
// se reestructura la tabla lo primero. Si se comprobase que hay que insertar el elemento
// antes de reestructurar la tabla, habría que localizar su índice 2 veces, y la tabla
// al quedar bastante llena no sería tan efectiva
int buscar (char* clave) {
	if ((float)(TS.ocupado + 1) / (float)TS.tamano >= 0.75)
		reestructurarTabla ();

	int indice = localizar (clave);
	if (TS.memoria[indice].lexema[0] == VACIO || TS.memoria[indice].lexema[0] == BORRADO) {
		insertar (clave, indice, ID);
	}
	return TS.memoria[indice].codigo;
}


// función simple para imprimir el contenido de la tabla hash
void imprimirTabla () {
	printf ("---------------------------------\n");
	for (int i = 0; i < TS.tamano; i++)
		printf ("| %d\t| %-12s\t\t|\n", i, TS.memoria[i].lexema);
	printf("---------------------------------\n");
}
