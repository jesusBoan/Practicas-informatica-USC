#include "pila.h"


// estructura de los elementos de la pila
struct elemento_pila {
	struct elemento_pila * siguiente;
	int valor;
};


// puntero al tope de la pila
struct elemento_pila * ultimo = NULL;


// inserción de un elemento en la pila, reserva memoria y modifica los punteros necesarios
void insertarPila (int num) {
	// reservo memoria, "apunto" el puntero del nuevo al viejo, y el nuevo pasa a ser el tope
	struct elemento_pila * nuevo = (struct elemento_pila *) malloc (sizeof (struct elemento_pila));
	nuevo -> siguiente = ultimo;
	ultimo = nuevo;
	nuevo -> valor = num;
}


// borrado de un elemento de la pila. Si el elemento tiene valor 0, simplemente devuelve 0
// ya que nunca se puede sacar este primer elemento de la pila
int quitarPila () {
	int resultado;
	if (ultimo -> valor == 0) resultado = 0;
	else {
		resultado = ultimo -> valor;
		struct elemento_pila * tmp = ultimo -> siguiente;
		free (ultimo);
		ultimo = tmp;
	}
	return resultado;
}


// devuelve el valor que está en el tope de la pila
int mirarPila () {
	if (ultimo != NULL)
		return ultimo -> valor;
	else
		return 0;
}


// inicializa la pila con un primer elemento con valor 0. Dicho elemento
// no se sacará de la pila nunca
void inicializarPila () {
	insertarPila (0);
}


// función para borrar la pila y liberar la memoria
void borrarPila () {
	while (mirarPila () != 0) quitarPila ();
	while (ultimo != NULL) {
		struct elemento_pila * tmp = ultimo -> siguiente;
		free (ultimo);
		ultimo = tmp;
	}
}
