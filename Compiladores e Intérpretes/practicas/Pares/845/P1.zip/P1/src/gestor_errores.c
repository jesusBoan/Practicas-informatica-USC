#include "gestor_errores.h"

void imprimirError (char * buffer, char * error) {
	printf (COLOR_ROJO
			"--------------------------------------\n"
			"Error analizando el lexema: %s\n"
			"Motivo: %s\n"
			"--------------------------------------\n"
			COLOR_RESET, buffer, error);
}
