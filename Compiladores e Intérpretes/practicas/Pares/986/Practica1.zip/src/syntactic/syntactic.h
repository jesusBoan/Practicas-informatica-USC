#ifndef SYNTACTIC_H
#define SYNTACTIC_H

/**
 * Inicia o análisis sintáctico
 */
void startSyntacticAnalysis();

#endif /* SYNTACTIC_H */