Para compilar el código, recomendamos hacerlo con la opción -O0, que sería:
$ gcc -O0 -o ejecutame intercambio_lazos.c 

Para ejecutar el programa, simplemente:
$ ./ejecutame

Si se desea, se puede cambiar en el propio .c el valor de N e ITER. Los valores utilizados para el informe se pueden ver en el primer printf de las propias capturas del mismo.
Ya que es un requisito que N e ITER sean constantes del código, no es posible modificar su valor pasándolo por línea de comandos. Modificar el .c es la única manera.

En la propia entrega se adjunta el código ensamblador en el fichero ensamblador.s para mayor comodidad. Si se desea, se puede generar ese mismo fichero con:
$ gcc -O0 -S -o ensamblador.s intercambio_lazos.c 


