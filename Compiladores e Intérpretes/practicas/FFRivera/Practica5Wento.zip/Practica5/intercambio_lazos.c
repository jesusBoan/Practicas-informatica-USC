#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>

#define N 1000
#define ITER 500
	
struct timeval inicio1, final1, inicio2, final2;
double tiempo1, tiempo2;

int main(int argc, char** argv) {

	printf("EJECUCIONES CON N=%d E ITER=%d:\n\n", N, ITER);

	//Variables originales del código
	int i, j, k;
	float x[N][N], y[N][N];

	//Variable que indica el máximo que puede generar el rand
	int a = 10;

	//Variables en las que se guardarán los resultados de cada una de las 10 iteraciones
	float valoresOriginales[10];
	float valoresOptimizados[10];

	//Inicializamos las matrices
	srand(time(NULL));
	for(i=0; i<N; i++) {
		for(j=0; j<N; j++) {
			x[i][j] = (float)rand()/(float)(RAND_MAX/a);
			y[i][j] = (float)rand()/(float)(RAND_MAX/a);
		}
	}

	//Ejecutamos el código 10 veces
	for(int n = 0; n < 10; n ++) {
		//VERSION ORIGINAL
		gettimeofday(&inicio1,NULL);
		for(k=0; k<ITER; k++){ 
			for(i=0; i<N; i++) {
				for(j=0; j<N; j++) {
					y[j][i] = x[j][i] * 3.0;
				}
			}
		} 
		gettimeofday(&final1,NULL);
		
		//VERSION OPTIMIZADA
		gettimeofday(&inicio2,NULL);
		for(k=0; k<ITER; k++){
			for(j=0; j<N; j++){
				for(i=0; i<N; i++){
					y[j][i] = x[j][i] * 3.0;
				}
			}
		}
		gettimeofday(&final2,NULL);

		//Imprimimos los resultados, ylos guardamos en los array de resultados
		tiempo1 = (final1.tv_sec-inicio1.tv_sec+(final1.tv_usec-inicio1.tv_usec)/1.e6);
		valoresOriginales[n] = tiempo1;
		printf("Tiempo del codigo sin optimizar %d: %f\n",n+1, tiempo1);

		tiempo2 = (final2.tv_sec-inicio2.tv_sec+(final2.tv_usec-inicio2.tv_usec)/1.e6);
		valoresOptimizados[n] = tiempo2;
		printf("Tiempo del codigo optimizado %d: %f\n\n",n+1, tiempo2);
	}

	//Imprimimos la media de cada array de resultados
	double media = 0;
	for(i=0; i<10; i++)media += valoresOriginales[i];
	printf("Tiempo medio de la version original: %f\n", media/10);

	media = 0;
	for(i=0; i<10; i++)media += valoresOptimizados[i];
	printf("Tiempo medio de la version optimizada: %f\n", media/10);

	return 0;
}
