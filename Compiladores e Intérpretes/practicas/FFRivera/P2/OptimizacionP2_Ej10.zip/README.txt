Este zip contiene:
-El informe sobre el ejercicio
-El código con matrices estáticas (main.c)
-El código con matrices dinámicas (mainDinamico.c)
-El script de ejecución (ejecucion.sh)

Para ejecutar uno de los programas sólo hace falta ejecutar:
$ bash ejecucion.sh

Dentro del script se especifica qué código se va a compilar.