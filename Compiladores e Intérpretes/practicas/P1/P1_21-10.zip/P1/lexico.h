#include "abb.h"
#include "sistemaEntrada.h"
#include <stdlib.h>
#include <stdio.h>

/** 
 * Devuelve la estructura 'e' correspondiente del siguiente 
 * elemento léxico al analizador sintáctico. Si es un 
 * identificador nuevo lo introduce en el árbol A. 
 * Devuelve 1 si el lexema es el fin de fichero y 0 en
 * caso contrario.
 * @param A Puntero al árbol binario.
 * @param e Elemento léxico donde se guarda el valor del siguiente lexema.
 */
int siguienteElemento(abb *A, el * e); 