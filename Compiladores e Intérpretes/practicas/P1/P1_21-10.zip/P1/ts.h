#include <stdio.h>
#include "abb.h"
#include "definiciones.h"

/*Función que crea el árbol e inserta en él las palabras reservadas junto a sus valores
de definiciones.h*/
void inicializar(abb *A);

/*Función de impresión de los elementos almacenados en la tabla*/
void imprimirTabla(abb *A);

/*Función que libera la memoria reservada para la tabla*/
void destruirTabla(abb *A);

void busca(abb *A, char *cadena); //esta la llama el analizador léxico para que busque un elemento, si no está, lo inserta. La función devuelve la constante identificadora del elemento