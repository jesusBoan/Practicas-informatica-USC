
/**
 * Función que imprime un mensaje de error junto con su número de línea 
 * si es especificada. Si numeroLinea es igual a 0 entonces sólo se 
 * imprime el mensaje.
 * @param mensaje String con el mensaje
 * @param numeroLinea número de la línea en donde se encuentra el error
*/
void printError(char * mensaje, int numeroLinea);