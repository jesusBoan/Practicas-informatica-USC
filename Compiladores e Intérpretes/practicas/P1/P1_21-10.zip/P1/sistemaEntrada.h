#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define TAMANO_BLOQUE 64
#define CENTINELA '\0'

/**
 * Función que abre el fichero de lectura, inicializa los buffers y punteros
 * y carga el primer bloque de caracteres.
 * @param pathFichero path del fichero de lectura
 */
int inicializarSistemaEntrada(char* pathFichero);

/*Función que manda una posición para atrás al puntero 'delantero'.*/
void devolver();
/*Función que devuelve el siguiente caracter en el buffer.*/
char siguienteCaracter();
/*Libera la memoria dinámica reservada en el sistema de entrada.*/
void freeSistemaEntrada();