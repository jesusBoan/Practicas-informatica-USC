#include "lexico.h"
#include "definiciones.h"
#include "gestorErrores.h"
#include <ctype.h>

//el tamaño máximo del lexema va a ser el tamaño de bloque
#define tamanoMaximoLexema TAMANO_BLOQUE
//el tamaño que almacenamos de un lexema al principio, si necesita más, almacenaremos más
#define tamanoLexemaInicial 8

//esta variable nos va a servir para mandar mensajes de error más precisos
int numeroDeLinea = 1;
/*Variable queguardará el tipo de definiciones.h correspondiente cuando se encuantre un lexema
y así sabremos qué valor entero asignarle el elementoLéxico devuelto al Analizador Sintáctico.*/
int tipoLexema = 0;
/*Variable que aumentará su valor en 1 cada vez que ocupemos la memoria reservada en el lexema.
Esto nos permitirá reservar a mayores tantos chars como indica 'tamanoLexemaInicial'.*/
int numeroRealloc;

/*Definimos funciones*/
void direccionarAutomata(char caracter, tipoclave lexema);

void buscarDelimitadorAlfanumerico(tipoclave lexema);
int esDelimitadorAlfanumerico(char caracter);

void buscarDelimitadorNumerico(tipoclave lexema);
int esDelimitadorEntero(char caracter);
int esDelimitadorHexadecimal(char caracter);
int esDelimitadorFlotante(char caracter);
int esDelimitadorFlotanteExponencial(char caracter);

void buscaDelimitadorString(tipoclave lexema);
int esDelimitadorString(char caracter, char tipoCadena);

int buscarDelimitadorOperador(tipoclave lexema, char caracter);

char quitarComentario();
char quitarComentarioString(char tipoComillas);

int siguienteElemento(abb *A, el *e)
{
    char caracterActual;
    numeroRealloc = 1;

    //el lexema con el que vamos a trabajar localmente
    tipoclave lexema = NULL;
    lexema = (char *)malloc(tamanoLexemaInicial * sizeof(char));

    caracterActual = siguienteCaracter();
    //si el caracter es el fin de fichero, entonces lo devolvemos
    if (caracterActual == EOF)
    {
        *(lexema + 0) = '\0';
        lexema = realloc(lexema, sizeof(char));
        setElementoLexico(e, lexema, EOF);
        free(lexema);
        return 1;
    }

    /*Comprobamos que no hay tabulaciones, espacios en blanco o 
    saltos de línea ya que eso no lo vamos a leer al principio del fichero.*/
    /*Tenemos que librarnos de comentarios hasta el próximo caracter.
    Los siguientes if() los necesitamos por si aparece un comentario de primeras.*/
    if (caracterActual == '#')
    { //cuando encontramos un comentario
        caracterActual = quitarComentario();
    }
    /*Comentarios de comillas triples, bien sean simples o dobles.
    En la función sólo quitará el comentario en caso de que encuentre las comillas triples.*/
    if (caracterActual == '\'' || caracterActual == '"')
    {
        quitarComentarioString(caracterActual);
    }
    /*este bucle nos permite librarnos de espacios en blanco y comentarios que pueda haber
    a continuación*/
    while (isspace(caracterActual)) //isspace() checkea que no sea \t, \n, line feed, espacio...
    {
        caracterActual = siguienteCaracter();
        if (caracterActual == '#')
        { //cuando encontramos un comentario
            caracterActual = quitarComentario();
        }

        if (caracterActual == '\'' || caracterActual == '"')
        {
            caracterActual = quitarComentarioString(caracterActual);
        }
    }

    //en base al primer caracter, entramos en un autómata u otro y vamos modificando el lexema.
    direccionarAutomata(caracterActual, lexema);

    /*Aquí decidimos qué hacer dependiendo del tipo de lexema que hayamos encontrado.
    Por defecto estará a 0, que es el valor de los operadores y delimitadores simples.*/
    if (!tipoLexema)
    { //si es de un solo caracter
        //se devuelve su valor ASCII
        setElementoLexico(e, lexema, (int)(*(lexema + 0)));
        tipoLexema = 0;
    }
    else if (tipoLexema == ID)
    {
        buscarElemento(A, e, lexema);
        tipoLexema = 0; //lo volvemos a poner a 0 por si los siguientes lexemas no son Identificadores
    }
    else
    { //si es cualquier otra cosa, se le pasa el código de definiciones.h que le corresponde
        setElementoLexico(e, lexema, tipoLexema);
        tipoLexema = 0;
    }
    /*liberamos memoria*/
    free(lexema);
    return 0;
}

/*función que analiza el caracter y lo envía al autómata correspondiente.
Cuando determinamos el tipo de elemento que está entrando, entonces vamos a buscar su delimitador.
Por ejemplo: si metemos un caracter 'a', sabemos que va a ser una cadena alfanumérica, por lo que 
seguiremos pidiendo caracteres válidos hasta que encontremos un delimitador de alfanuméricas.*/
void direccionarAutomata(char caracter, tipoclave lexema)
{
    int tamanoCadena = 0;

    //comprobamos si es una cadena, si lo es, nos metemos a buscar el delimitador de cadenas
    if (isalpha(caracter) || caracter == '_')
    {
        *(lexema + tamanoCadena) = caracter;
        buscarDelimitadorAlfanumerico(lexema);
    }
    else if (isdigit(caracter))
    {
        *(lexema + tamanoCadena) = caracter;
        buscarDelimitadorNumerico(lexema);
    }
    else if (caracter == '.')
    { //es un float que empieza por '.'
        *(lexema + tamanoCadena) = caracter;
        buscarDelimitadorNumerico(lexema);
        if (tipoLexema == ENTERO)
        {
            tipoLexema = FLOAT;
        }
    }
    else if (caracter == '\'' || caracter == '"')
    { //o comilla simple o doble
        *(lexema + tamanoCadena) = caracter;
        buscaDelimitadorString(lexema);
    }
    else
    { //para los siguientes caracteres no nos molestamos en hacer una función
        //caracteres que sólo pueden ir solos
        if (caracter == ';' || caracter == ',' || caracter == '~' || caracter == '[' || caracter == ']' || caracter == '{' || caracter == '}' || caracter == '(' || caracter == ')')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
        }
        else
        {
            tamanoCadena = buscarDelimitadorOperador(lexema, caracter);
        }
        lexema = realloc(lexema, tamanoCadena * sizeof(char));
    }
}

/*Función llamada cuando el primer elemento de un lexema es el inicio de una cadena alfanumérica.
Esta función va almacenando los caracteres de la cadena alfanumérica que lee por el sistema de entrada
si estos son válidos (alfabeto, '_' y números). Cuando llega a un delimitador para.*/
void buscarDelimitadorAlfanumerico(tipoclave lexema)
{
    char caracter = siguienteCaracter();
    int encontrado = 0, tamanoCadena = 1;

    //mientras no encontremos el delimitador
    while (!encontrado)
    {
        /*Buscamos si el caracter es delimitador*/
        encontrado = esDelimitadorAlfanumerico(caracter);

        /*Si lo es, cortamos la memoria sobrante de la cadena*/
        if (encontrado)
        {
            lexema = realloc(lexema, tamanoCadena * sizeof(char));
            tipoLexema = ID; //el tipo de lexema encontrado es un identificador
            //devolver(); //quizá poner una condición del tipo de delimitador(si no es espacio etc.)
        }
        /*Si no esun delimitador, entonces buscaremos si es válido y en caso
        afirmativo lo añadimos al lexema.*/
        else
        {
            //si ya habíamos llegado al tamaño máximo reservado, entonces reservaremos otro tanto
            if ((tamanoCadena % tamanoLexemaInicial) == 0)
            {
                numeroRealloc++;
                lexema = realloc(lexema, numeroRealloc * tamanoLexemaInicial * sizeof(char));
            }
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            caracter = siguienteCaracter();
        }
    }
}

/*Función que devuelve 0 si el caracter no es un delimitador alfanumérico y
1 en caso afirmativo*/
int esDelimitadorAlfanumerico(char caracter)
{
    if (isalpha(caracter) || isdigit(caracter) || caracter == '_')
    {
        return 0;
    }
    else
    {
        //aquí comprobamos los delimitadores, si son delimitadores como el espacio o el salto delínea no tenemos que volver a leerlos
        if (caracter == 9 /*tab*/ || caracter == 10 /*line feed*/ || caracter == 13 /*\n*/ || caracter == 32 /*espacio*/)
        {
            if (caracter == 13)
                numeroDeLinea++; //cada vez que haya un salto de línea sumamos 1 al contador
            return 1;
        }
        else if ((caracter > 32 && caracter < 48) || (caracter > 57 && caracter < 65) || (caracter > 90 && caracter < 95) || caracter == 96 || (caracter > 122 && caracter < 127))
        {
            //estos caracteres delimitadores los tenemos que devolver
            devolver();
            return 1;
        }
        else
        {
            //erro
        }
    }
}

/*Función llamada para encontrar el delimitador de una cadena numérica.
Cuando lo encuentra para y tendrá guardada en lexema la cadena.*/
void buscarDelimitadorNumerico(tipoclave lexema)
{
    char caracter = siguienteCaracter();
    int encontrado = 0, tamanoCadena = 1;

    if (*(lexema + 0) == '.' && (isspace(caracter) || !isdigit(caracter)))
    { //aquí solo es un '.'
        lexema = realloc(lexema, 1 * sizeof(char));
        tipoLexema = 0;
        if (!isspace(caracter))
            devolver(); //si no viene un espacio después, tenemos que devolver el siguiente caracter
    }
    else if (*(lexema + 0) == '0' && (caracter == 'x' || caracter == 'X'))
    { //hexadecimal
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        while (!encontrado)
        {
            encontrado = esDelimitadorHexadecimal(caracter);

            if (encontrado)
            {
                lexema = realloc(lexema, tamanoCadena * sizeof(char));
                tipoLexema = ENTERO;
            }
            else
            {
                //si ya habíamos llegado al tamaño máximo reservado, entonces reservaremos otro tanto
                if ((tamanoCadena % tamanoLexemaInicial) == 0)
                {
                    numeroRealloc++;
                    lexema = realloc(lexema, numeroRealloc * tamanoLexemaInicial * sizeof(char));
                }
                *(lexema + tamanoCadena) = caracter;
                tamanoCadena++;
                caracter = siguienteCaracter();
            }
        }
    }
    else if (caracter == '.' || caracter == 'e')
    { //estamos en punto flotante
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        if (caracter == '.')
        { //puede ser un '.' al principio
            caracter = siguienteCaracter();
            while (!encontrado)
            {
                encontrado = esDelimitadorFlotante(caracter);
                if (encontrado)
                {
                    lexema = realloc(lexema, tamanoCadena * sizeof(char));
                    tipoLexema = FLOAT;
                }
                else
                {
                    //si ya habíamos llegado al tamaño máximo reservado, entonces reservaremos otro tanto
                    if ((tamanoCadena % tamanoLexemaInicial) == 0)
                    {
                        numeroRealloc++;
                        lexema = realloc(lexema, numeroRealloc * tamanoLexemaInicial * sizeof(char));
                    }
                    *(lexema + tamanoCadena) = caracter;
                    tamanoCadena++;
                    caracter = siguienteCaracter();
                }
            }
        }
        else if (caracter == 'e')
        { //o puede empezar con un 'e' el principio,  los delimitadores son diferentes
            caracter = siguienteCaracter();
            while (!encontrado)
            {
                encontrado = esDelimitadorFlotanteExponencial(caracter);
                if (encontrado)
                {
                    lexema = realloc(lexema, tamanoCadena * sizeof(char));
                    tipoLexema = FLOAT;
                }
                else
                {
                    //si ya habíamos llegado al tamaño máximo reservado, entonces reservaremos otro tanto
                    if ((tamanoCadena % tamanoLexemaInicial) == 0)
                    {
                        numeroRealloc++;
                        lexema = realloc(lexema, numeroRealloc * tamanoLexemaInicial * sizeof(char));
                    }
                    *(lexema + tamanoCadena) = caracter;
                    tamanoCadena++;
                    caracter = siguienteCaracter();
                }
            }
        }
    }
    //si es un entero 'normal' de más de 1 dígito, estos no pueden empezar por '0'
    else if (*(lexema + 0) != '0' && isdigit(caracter))
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        while (!encontrado)
        {
            encontrado = esDelimitadorEntero(caracter);

            if (encontrado)
            {
                lexema = realloc(lexema, tamanoCadena * sizeof(char));
                tipoLexema = ENTERO;
            }
            else
            {
                //si ya habíamos llegado al tamaño máximo reservado, entonces reservaremos otro tanto
                if ((tamanoCadena % tamanoLexemaInicial) == 0)
                {
                    numeroRealloc++;
                    lexema = realloc(lexema, numeroRealloc * tamanoLexemaInicial * sizeof(char));
                }
                *(lexema + tamanoCadena) = caracter;
                tamanoCadena++;
                caracter = siguienteCaracter();
            }
        }
    }
    else
    {
        /*ints de 1 sólo dígito*/
        while (!encontrado)
        {
            encontrado = esDelimitadorEntero(caracter);

            if (encontrado)
            {
                lexema = realloc(lexema, tamanoCadena * sizeof(char));
                tipoLexema = ENTERO;
            }
            else
            {
                //si ya habíamos llegado al tamaño máximo reservado, entonces reservaremos otro tanto
                if ((tamanoCadena % tamanoLexemaInicial) == 0)
                {
                    numeroRealloc++;
                    lexema = realloc(lexema, numeroRealloc * tamanoLexemaInicial * sizeof(char));
                }
                *(lexema + tamanoCadena) = caracter;
                tamanoCadena++;
                caracter = siguienteCaracter();
            }
        }
    }
}

/*Analiza si el caracter es un delimitador de cadenas enteras*/
int esDelimitadorEntero(char caracter)
{
    if (caracter == '_' || isdigit(caracter))
    { //mientras sea un entero o '_', sigue siendo válido
        return 0;
    }
    else
    {
        //aquí comprobamos los delimitadores, si son delimitadores como el espacio o el salto delínea no tenemos que volver a leerlos
        if (caracter == 9 /*tab*/ || caracter == 10 /*line feed*/ || caracter == 13 /*\n*/ || caracter == 32 /*espacio*/)
        {
            if (caracter == 13)
                numeroDeLinea++; //cada vez que haya un salto de línea sumamos 1 al contador
            return 1;
        }
        else
        {
            devolver();
            return 1;
        }
    }
}

/*Analiza si el caracter es un delimitador de cadenas enteras hexadecimales*/
int esDelimitadorHexadecimal(char caracter)
{
    if (caracter == '_' || isxdigit(caracter))
    { //mientras sea un hexadecimal o '_', sigue siendo válido
        return 0;
    }
    else
    {
        //aquí comprobamos los delimitadores, si son delimitadores como el espacio o el salto delínea no tenemos que volver a leerlos
        if (caracter == 9 /*tab*/ || caracter == 10 /*line feed*/ || caracter == 13 /*\n*/ || caracter == 32 /*espacio*/)
        {
            if (caracter == 13)
                numeroDeLinea++; //cada vez que haya un salto de línea sumamos 1 al contador
            return 1;
        }
        else
        {
            devolver();
            return 1;
        }
    }
}

/*cuando aparece un '.'*/
int esDelimitadorFlotante(char caracter)
{
    if (isdigit(caracter) || caracter == '_' || caracter == 'e')
    {
        return 0;
    }
    else
    {
        //aquí comprobamos los delimitadores, si son delimitadores como el espacio o el salto delínea no tenemos que volver a leerlos
        if (caracter == 9 /*tab*/ || caracter == 10 /*line feed*/ || caracter == 13 /*\n*/ || caracter == 32 /*espacio*/)
        {
            if (caracter == 13)
                numeroDeLinea++; //cada vez que haya un salto de línea sumamos 1 al contador
            return 1;
        }
        else
        {
            devolver();
            return 1;
        }
    }
}

/*cuando en un flotante aparece una 'e' o 'E'*/
int esDelimitadorFlotanteExponencial(char caracter)
{
    if (isdigit(caracter) || caracter == '-' || caracter == '+')
    {
        return 0;
    }
    else
    {
        //aquí comprobamos los delimitadores, si son delimitadores como el espacio o el salto delínea no tenemos que volver a leerlos
        if (caracter == 9 /*tab*/ || caracter == 10 /*line feed*/ || caracter == 13 /*\n*/ || caracter == 32 /*espacio*/)
        {
            if (caracter == 13)
                numeroDeLinea++; //cada vez que haya un salto de línea sumamos 1 al contador
            return 1;
        }
        else
        {
            devolver();
            return 1;
        }
    }
}

/*Busca si es una string cuando llega un ' o un " */
void buscaDelimitadorString(tipoclave lexema)
{
    char caracter = siguienteCaracter();
    char tipoCadena = *(lexema + 0); //guardamos el tipo de comillas que inician la cadena, simples o dobles
    int encontrado = 0, tamanoCadena = 1;

    if (caracter == tipoCadena)
    { //aquí tenemos '' o "" ya la devolvemos
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;

        lexema = realloc(lexema, tamanoCadena * sizeof(char));
        tipoLexema = STRING; //el tipo de lexema encontrado es una string
        if (!isspace(caracter))
            devolver();
    }
    else
    { //aquí vamos a buscar la cadena simple 'asdfg' o "asdfg"
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();

        while (!encontrado)
        {
            /*Buscamos si el caracter es delimitador.
            E introducimos el tipo de cadena que es.*/
            if ((encontrado = esDelimitadorString(caracter, tipoCadena)))
            {
                //guardamos esas comillas como un caracter más
                if ((tamanoCadena % tamanoLexemaInicial) == 0)
                {
                    numeroRealloc++;
                    lexema = realloc(lexema, numeroRealloc * tamanoLexemaInicial * sizeof(char));
                }
                *(lexema + tamanoCadena) = caracter;
                tamanoCadena++;

                lexema = realloc(lexema, tamanoCadena * sizeof(char));
                tipoLexema = STRING; //el tipo de lexema encontrado es una string
            }
            /*Si no es un delimitador, entonces buscaremos si es válido y en caso
            afirmativo lo añadimos al lexema.*/
            else
            {
                //si ya habíamos llegado al tamaño máximo reservado, entonces reservaremos otro tanto
                if ((tamanoCadena % tamanoLexemaInicial) == 0)
                {
                    numeroRealloc++;
                    lexema = realloc(lexema, numeroRealloc * tamanoLexemaInicial * sizeof(char));
                }
                *(lexema + tamanoCadena) = caracter;
                tamanoCadena++;
                caracter = siguienteCaracter();
            }
        }
    }
}

/*Busca el mismo caracter de inicio de cadena 'tipocadena': ' o " */
int esDelimitadorString(char caracter, char tipoCadena)
{
    if (caracter != tipoCadena)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

/*Busca el delimitador de un operador de mas de un caracter.
Devuelve el tamaño de la cadena.*/
int buscarDelimitadorOperador(tipoclave lexema, char caracter)
{
    int tamanoCadena = 0;
    if (caracter == '+')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        if ((caracter = siguienteCaracter()) == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = MASIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '-')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '=' || caracter == '>')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = MENOSIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '*')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '*')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            caracter = siguienteCaracter();
            if (caracter == '=')
            {
                *(lexema + tamanoCadena) = caracter;
                tamanoCadena++;
                tipoLexema = PORPORIGUAL;
            }
            else
            {
                tipoLexema = PORPOR;
                devolver();
            }
        }
        else if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = PORIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '/')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '/')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            caracter = siguienteCaracter();
            if (caracter == '=')
            {
                *(lexema + tamanoCadena) = caracter;
                tamanoCadena++;
                tipoLexema = ENTREENTREIGUAL;
            }
            else
            {
                tipoLexema = ENTREENTRE;
                devolver();
            }
        }
        else if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = ENTREIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '%')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = PORCENTAJEIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '@')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = ARROBAIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '<')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '<')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            caracter = siguienteCaracter();
            if (caracter == '=')
            {
                *(lexema + tamanoCadena) = caracter;
                tamanoCadena++;
                tipoLexema = MENORMENORIGUAL;
            }
            else
            {
                tipoLexema = MENORMENOR;
                devolver();
            }
        }
        else if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = MENORIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '>')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '>')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            caracter = siguienteCaracter();
            if (caracter == '=')
            {
                *(lexema + tamanoCadena) = caracter;
                tamanoCadena++;
                tipoLexema = MAYORMAYORIGUAL;
            }
            else
            {
                tipoLexema = MAYORMAYOR;
                devolver();
            }
        }
        else if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = MAYORIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '&')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = AMPERSANDIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '|')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = PIPELINEIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '^')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = CIRCUNFLEJOIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == ':')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = DOSPUNTOSIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '=')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = IGUALIGUAL;
        }
        else
        {
            devolver();
        }
    }
    else if (caracter == '!')
    {
        *(lexema + tamanoCadena) = caracter;
        tamanoCadena++;
        caracter = siguienteCaracter();
        if (caracter == '=')
        {
            *(lexema + tamanoCadena) = caracter;
            tamanoCadena++;
            tipoLexema = EXCLAMACIONIGUAL;
        }
    }
    else
    {
        printError("Caracter no válido", 0);
    }
    return tamanoCadena;
}

/*Función que una vez reconocido el caracter '#', se salta el resto de la línea*/
char quitarComentario()
{
    char caracter;
    while ((caracter = siguienteCaracter()) != 10 /*line feed*/);
    return caracter;
}

/*Función que borra un comentario de comillas triples.
En caso de no encontrar triples comillas, devolverá los caracteres.*/
char quitarComentarioString(char tipoComillas)
{
    int caracteresLeidos = 0;   //variable para controlar el tamaño máximo de lexema
    char caracter;
    int encontrado = 0;
    int numeroDelimitadores = 0;

    if ((caracter = siguienteCaracter()) == tipoComillas)
    { //aquí tenemos '' o ""
        if ((caracter = siguienteCaracter()) == tipoComillas)
        { //aquí tenemos ''' o """
            caracteresLeidos = 3;   //hemos leído 3 comillas
            caracter = siguienteCaracter();
            //mientras no encontremos el delimitador
            while (!encontrado)
            {
                if((caracteresLeidos++) > tamanoMaximoLexema){
                    printError("Tamano máximo de lexema superado", 0);
                }
                /*Buscamos si el caracter es delimitador.
                E introducimos el tipo de cadena que es.*/
                if (esDelimitadorString(caracter, tipoComillas))
                {
                    numeroDelimitadores++; //aumentamos el número de comillas que llegan

                    if (numeroDelimitadores == 3)
                    { //si llegó la tercera comilla cerramos el string
                        encontrado = 1;
                        caracter = siguienteCaracter();
                    }
                    else
                    {
                        caracter = siguienteCaracter();
                    }
                }
                /*Si no es un delimitador, buscamos el siguiente caracter*/
                else
                {
                    caracter = siguienteCaracter();
                }
            }
        }
        else
        {
            /*devolvemos las primeras y segundas comillas y el caracter que no son comillas*/
            devolver();
            devolver();
            devolver();
            caracter = siguienteCaracter();
        }
    }
    else
    {
        /*devolvemos las primeras comillas y el caracter que no son comillas*/
        devolver();
        devolver();
        caracter = siguienteCaracter();
    }
    return caracter;
}