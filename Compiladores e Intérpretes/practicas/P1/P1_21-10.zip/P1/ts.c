#include "ts.h"

//listas de inicialización de la TS
char * listaReservadas[] = {
        "import", "as", "def", "for", "in", "if", "elif", "else", "return"
    };
int listaConstantes[] = {
    IMPORT, AS, DEF, FOR, IN, IF, ELIF, ELSE, RETURN
};

void inicializar(abb *A){
    crearArbol(A);
    for(int i = 0; i<9; i++){
        insertar(A, crearElementoLexico(listaReservadas[i], listaConstantes[i]));
    }
}


void imprimirTabla(abb *A){
    printf("---------------------------------------\n");
    printf("|\tTabla de Símbolos:\t      |\n");
    printf("---------------------------------------\n");
    if(!es_vacio(*A)){
        imprimirArbol(*A);
    }
    printf("---------------------------------------\n");
}


void destruirTabla(abb *A){
    destruirArbol(A);
}