#include "sistemaEntrada.h"

/* variables que representan los buffers A y B, las usaremos 
para comprobar y guardar el estado de los punteros de lectura */
#define A 1
#define B 2

FILE *fp;
//punteros a los 2 buffers (A y B) y punteros de lectura y posición
char *bloqueA = NULL, *bloqueB = NULL, *inicio = NULL, *delantero = NULL;
//variables que guardan el valor numérico del buffer en el que están
int estadoInicio, estadoDelantero;
//variable que almacena el número de caracterse que acabamos de cargar al buffer
int numeroCaracteres;
//variable que nos sirve cuando necesitemos devolver caracteres y se cambie al anterior bloque
int cargarSiguienteBloque = 1;
//esta variablenos permite controlar la distancia
int longitudActualLexema = 0;

int cargarBloque();

int inicializarSistemaEntrada(char* pathFichero){
    fp = fopen(pathFichero, "r");
    if(fp == NULL){
        //print_error(Error al abrir el fichero);
        return -1;
    }

    numeroCaracteres = 0;
    estadoInicio = A;
    estadoDelantero = A;

    /*Reservamos memoria para los buffers, de un número de chars
    igual al tamaño máximo de bloque que hayamos especificado.
    Para su último caracter, metemos los centinelas.*/
    bloqueA = (char*)malloc(TAMANO_BLOQUE * sizeof(char));
    bloqueB = (char*)malloc(TAMANO_BLOQUE * sizeof(char));
    *(bloqueA + TAMANO_BLOQUE-1) = CENTINELA;
    *(bloqueB + TAMANO_BLOQUE-1) = CENTINELA;

    /*Los punteros de lectura tienen reservado 1 char y apuntan
    a la primera posición del primer buffer*/
    inicio = (char*)malloc(sizeof(char));
    delantero = (char*)malloc(sizeof(char));
    inicio = &bloqueA[0];
    delantero = &bloqueA[0];

    //cargamos el primer bloque para luego poder leer
    cargarBloque();

    return 0;
}

/*Función que carga el buffer en el que delantero va a leer con los siguientes
caracteres del fichero indicado.*/
int cargarBloque(){

    /*Cargamos el bloque que vayamos a leer a continuación*/
    if(estadoDelantero == A){
        numeroCaracteres = fread(bloqueA, sizeof(char), TAMANO_BLOQUE-1, fp);
    }else{
        numeroCaracteres = fread(bloqueB, sizeof(char), TAMANO_BLOQUE-1, fp);
    }
    
    /*Si cargamos menos caracteres de los que caben en un bloque entonces
    habremos llegado al final del fichero, y entonces introducimos el
    caracter de fin de fichero en la posición correspondiente.*/
    if(numeroCaracteres<TAMANO_BLOQUE-1){
        if(estadoDelantero == A)    *(bloqueA + numeroCaracteres) = EOF;
        else    *(bloqueB + numeroCaracteres) = EOF;
    }

    /*printf("Nuevo Bloque:\n");
    for (int i = 0; i < TAMANO_BLOQUE; i++)
    {
        if(estadoDelantero == A){
            printf("%c", *(bloqueA + i));
        }else if(estadoDelantero == B) printf("%c", *(bloqueB + i));
    }
    printf("\n");*/
}

char siguienteCaracter(){
    char caracterAEnviar;

    /*Si hemos llegado al centinela, cambiamos de bloque a delantero y cargamos
    el pŕoximo bloque si es necesario*/
    if (*delantero == CENTINELA)
    {
        if (estadoDelantero == A)
        {
            estadoDelantero = B;
            delantero = &bloqueB[0];            
        }else{
            estadoDelantero = A;
            delantero = &bloqueA[0];
        }

        if(cargarSiguienteBloque){
            cargarBloque();
        }else{
            cargarSiguienteBloque = 1;
        }        
        
        caracterAEnviar = *delantero;
        delantero++;
    }else{
        caracterAEnviar = *delantero;
        delantero++;
    }
    return caracterAEnviar;
}

void devolver(){
    delantero--;
    /*Si estaba en la posición 0, entonces al hacer el 'delantero--' ahora estará en la última posición
    del mismo bloque: es decir, si estaba en bloqueA[0] ahora estará en bloqueA[N-1].
    Si pasa esto, entonces tenemos que cambiar el puntero al otro bloque, 1 posición detrás del centinela.
    Es decir, a bloqueB[N-2], que es donde está el caracter que queríamos leer de nuevo.*/
    if(*delantero == CENTINELA){
        if (estadoDelantero == A)
        {
            estadoDelantero = B;
            delantero = &bloqueB[TAMANO_BLOQUE-2];
            //le indicamos que no vuelva a cargar el siguiente bloque ya que perderiamos datos
            cargarSiguienteBloque = 0;
        }else{
            estadoDelantero = A;
            delantero = &bloqueA[TAMANO_BLOQUE-2]; 
            cargarSiguienteBloque = 0;
        }
    }
}

/*Función que libera la memoria dinámica reservada*/
void freeSistemaEntrada(){
    free(bloqueA);
    free(bloqueB);
    fclose(fp);
}