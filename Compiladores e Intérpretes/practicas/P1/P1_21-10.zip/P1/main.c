/*
* Author: 
* Description: Primer paso de un compilador de un archivo de código Python, contiene un analizador léxico y uno sintáctico 
* que saca los elementos detectados con su correpondiente código numérico por pantalla.
*/

#include <stdlib.h>
#include <stdio.h>
#include "sintactico.h"
#include "ts.h"
#include "sistemaEntrada.h"
#include "gestorErrores.h"

int main(int argc, char** argv){
    //fichero de lectura
    char *fichero = NULL;
    if(argc == 1)   fichero = "./wilcoxon.py";
    else if(argc == 2)    fichero = argv[1];
    else{
        printError("Error en los parámetros de entrada.", 0);
        return(EXIT_FAILURE);
    } 

    /*cargar la TS con las palabras reservadas aquí*/
    abb *TS = (abb*)malloc(sizeof(abb));
    
    /*Inicializa la TS con las palabras reservadas y sus constantes*/
    inicializar(TS);
    /*Imprime la TS inicial*/
    imprimirTabla(TS);
    /*El sistema de entrada carga el primer bloque de caracteres, 
    ahora ya está listo para empezar a leer*/
    inicializarSistemaEntrada(fichero);

    /*Llama a que se inicie el analizador sintáctico*/
    start(TS);

    //Imprimimos la TS final
    imprimirTabla(TS);

    /*liberar memoria*/
    freeSistemaEntrada();
    destruirTabla(TS);
    //imprimirTabla(TS);    //con esto podemos comprobar que se vació por completo

    return(EXIT_SUCCESS);
}